import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import App from './App';

test('renders navigation links', () => {
  render(
    <Router>
      <App />
    </Router>
  );
  const nav = screen.getByRole('navigation');
  expect(nav).toHaveTextContent(/Map/i);
  expect(nav).toHaveTextContent(/Register/i);
  expect(nav).toHaveTextContent(/Login/i);
});
