import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import Register from './components/Register';
import Login from './components/Login';
import io from 'socket.io-client';
import axios from 'axios';
import './App.css';

const socket = io('http://localhost:3001');

function App() {
  const [noiseReadings, setNoiseReadings] = useState([]);

  useEffect(() => {
    axios.get('/api/noise-data/latest').then((res) => {
      setNoiseReadings(res.data);
    });

    socket.on('new-noise-reading', (reading) => {
      setNoiseReadings((prevReadings) => [reading, ...prevReadings]);
    });

    return () => {
      socket.off('new-noise-reading');
    };
  }, []);

  return (
    <Router>
      <div className="App">
        <nav>
          <ul>
            <li>
              <Link to="/">Map</Link>
            </li>
            <li>
              <Link to="/register">Register</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
          </ul>
        </nav>
        <Switch>
          <Route path="/register" component={Register} />
          <Route path="/login" component={Login} />
          <Route path="/">
            <MapContainer center={[51.505, -0.09]} zoom={13} style={{ height: 'calc(100vh - 50px)', width: '100%' }}>
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {noiseReadings.map((reading) => (
                <Marker key={reading.id} position={[reading.latitude, reading.longitude]}>
                  <Popup>
                    Decibels: {reading.decibels}
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
