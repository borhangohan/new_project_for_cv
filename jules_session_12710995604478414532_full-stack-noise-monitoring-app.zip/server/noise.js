const express = require('express');
const db = require('./db');

module.exports = function(io) {
  const router = express.Router();

  router.post('/submit', async (req, res) => {
    const { latitude, longitude, decibels } = req.body;

    if (latitude === undefined || longitude === undefined || decibels === undefined) {
      return res.status(400).json({ msg: 'Please enter all fields' });
    }

    try {
      const newReading = await db.query(
        'INSERT INTO noise_readings (location, decibels) VALUES (ST_SetSRID(ST_MakePoint($1, $2), 4326), $3) RETURNING id, ST_X(location::geometry) as longitude, ST_Y(location::geometry) as latitude, decibels, created_at',
        [longitude, latitude, decibels]
      );

      const readingData = newReading.rows[0];
      io.emit('new-noise-reading', readingData);

      res.status(201).json(readingData);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error');
    }
  });

  router.get('/latest', async (req, res) => {
    try {
      const latestReadings = await db.query(
        'SELECT id, ST_X(location::geometry) as longitude, ST_Y(location::geometry) as latitude, decibels, created_at FROM noise_readings ORDER BY created_at DESC LIMIT 100'
      );
      res.json(latestReadings.rows);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server error');
    }
  });

  return router;
};
