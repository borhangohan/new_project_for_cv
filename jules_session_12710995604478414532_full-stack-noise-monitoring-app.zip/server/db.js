const { Pool } = require('pg');

const pool = new Pool({
  user: 'db_user',
  host: 'localhost',
  database: 'db_name',
  password: 'db_password',
  port: 5432,
});

module.exports = {
  query: (text, params) => pool.query(text, params),
};
