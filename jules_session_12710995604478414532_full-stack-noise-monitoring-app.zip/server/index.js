const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const port = 3001;

app.use(express.json());

app.use('/api/auth', require('./auth'));
const noiseRoutes = require('./noise')(io);
app.use('/api/noise-data', noiseRoutes);

app.get('/', (req, res) => {
  res.send('Hello World!');
});

io.on('connection', (socket) => {
  console.log('a user connected');
  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

http.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});
